# Election_Analysis
PyPoll with Python
